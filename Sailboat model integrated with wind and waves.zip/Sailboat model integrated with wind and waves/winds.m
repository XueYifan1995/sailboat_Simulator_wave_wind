function [dfx,dfy,dfk,dfn,vw_all,psi_all] = winds(psi,t,plot_wind)

if nargin == 2
    plot_wind=0;
end

rho=1.224;     %
g=9.81;
Loa=12;
AFw=4.25;   %
ALw=18;     %
Hm=1.2;     %
vw_mean=10;     %10m
psi_mean=-pi/2;     %
%% Davenport
dw=0.01;
w_max=1;
w=0.8:dw:w_max;
ks=0.01; %

global wind_init phi_wind_r psi_wind_r A;
if isempty(wind_init)==1
    wind_init=1;
    rd1 = RandStream('mt19937ar','Seed',60);
    phi_wind_r=2*pi*rand(rd1,length(w),1)';%�����λ
    rd2 = RandStream('mt19937ar','Seed',2);
    psi_wind_r=pi/1*rand(rd2,length(w),1)'-pi/2+psi_mean;%�������
    
    for i=1:length(w)
        n=w(i)/2/pi;
        X = 1200*n/vw_mean;
        s(i)=4*ks*vw_mean^2*X^2/(n*(1+X^2)^(4/3));
        A(i)=sqrt(2*s(i)*dw);
    end
    
    %�糡���ӻ�  
    xdist = 500;
    ydist = 500;
    xpoints = 15;
    ypoints = 15;
    vw_x= zeros(xpoints+1, ypoints+1)+vw_mean*cos(psi_mean);
    vw_y= zeros(xpoints+1, ypoints+1)+vw_mean*sin(psi_mean);   
    dx = xdist/xpoints;
    dy = ydist/ypoints;   
    xvec = 0:dx:xdist;
    yvec = 0:dy:ydist;
    t0=10;
    vw=w;
    for ix=1:xpoints+1
        for iy=1:ypoints+1                    
            for i=1:length(w)
                k=sqrt(w(i)^2/g);
                vw(i)=A(i)*cos(w(i)*t0-k*(xvec(ix)*cos(psi_wind_r(i))+yvec(iy)*sin(psi_wind_r(i)))+...
                    phi_wind_r(i));
                vw_x(ix,iy)=vw_x(ix,iy)+vw(i)*cos(psi_wind_r(i));
                vw_y(ix,iy)=vw_y(ix,iy)+vw(i)*sin(psi_wind_r(i));
            end
        end
    end
    if plot_wind
        figure
        quiver(xvec,yvec,vw_x,vw_y,'r')
    end
end

%% 
dfx=0;
dfy=0;
dfk=0;
dfn=0;

for i=0:length(w)
    if i==0
        vw_x0=vw_mean*cos(psi_mean);
        vw_y0=vw_mean*sin(psi_mean);
    else
        vw0=A(i)*cos(w(i)*t+phi_wind_r(i));              
        vw_x0=vw_x0++vw0*cos(psi_wind_r(i));
        vw_y0=vw_y0++vw0*sin(psi_wind_r(i));        
    end 
    vw_all= sqrt(vw_x0.^2+vw_y0.^2);
    psi_all=atan2(vw_y0,vw_x0);
    b=psi-psi_all;
end
            
    CX=-0.7*(ALw/AFw)*(cos(b)/(1-0.2*(1-0.7/0.95)*(sin(2*b)).^2));
    CY=-0.95*(sin(b)/(1-0.2*(1-0.7/0.95)*(sin(2*b)).^2));
    CK=1.1*CY;
    CN=(0.1/Loa-0.18*(b-pi/2))*CY;
    
    dfx = dfx + 0.5*rho*vw_all.^2*AFw.*CX;
    dfy = dfy + 0.5*rho*vw_all.^2*ALw.*CY;
    dfk = dfk + 0.5*rho*vw_all.^2*Loa*ALw.*CK;
    dfn = dfn + 0.5*rho*vw_all.^2*Loa*ALw.*CN;
%     end %%0508
% end
   psi_all=-psi_all+pi/2;
end