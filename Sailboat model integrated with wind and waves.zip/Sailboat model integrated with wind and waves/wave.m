function [dwx,dwy,dwk,dwn] = wave(psi,u,t, plot_spectrum, plot_realization)

if nargin == 3
    plot_spectrum=0;
    plot_realization=0;
end

% 
% Torsethaugen
% 
%% input
% psi 
% u 
% t 
%% parameter
L=12;           %
B=3.5;          %
T=2;            %
%% constant
g=9.81;%
rho=1025; %
%% 
% initialization
global wave_init Zeta_a  Omega  Phase  Wavenum  mu;    %
    psi_mean=0;     % 
if isempty(wave_init)==1
    wave_init=1;
    spectrum_type=3;%Torsethaugen
    Hs = 1.88;         % significant wave height
    To = 8.8;         % peak period of the wvae spectrum
    wo = 2*pi/To;   % peak frequency

    %---------------------------------
    hs=Hs;
%     Tp=To;           % Tp   = 2*pi/wo;
    omega_peak=wo;   %(wo��default 0��
    gamma=2;
    spread=2;
    depth=inf;
    nfreq=20;       %
    ndir=10;
    energylim=0.005;
    freq_cutoff=3;  %
    dir_cutoff=0;
    rand_freq=1;
    rand_dir=1;
    rand_seed=123;  %
   
    disp_flag=0;
    
    [Zeta_a, Omega, Phase, Wavenum, mu] = Wave_init(spectrum_type, hs, omega_peak, psi_mean,...
        gamma, spread, depth, nfreq, ndir, energylim, freq_cutoff, dir_cutoff, rand_freq, rand_dir,...
        rand_seed, plot_spectrum, plot_realization, disp_flag);
    %
end
%% 
dwx=0;
dwy=0;
dwn=0;
for i=1:length(Omega)                       % 
    chi=psi-mu(i);                             %
    we=Omega(i)-Omega(i)^2/g*u*cos(chi);       % 
    alp=Wavenum(i)*Zeta_a(i)*sin(we*t+Phase(i));        % wave slope
    dwx=dwx+rho*g*B*L*T*cos(chi)*alp;    
    dwy=dwy+rho*g*B*L*T*sin(chi)*alp;
    dwn=dwn+1/24*rho*g*B*L*(L^2-B^2)*sin(2*chi)*alp.^2;
end
dwk=dwy*T*0.6;

end